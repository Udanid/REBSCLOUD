<?php
$pgdomain="<change me>";
$pgInstanceId="<change me>";
$merchantId="<change me>";
$hashKey="<change me>";

header("pragma".": "."no-cache");
header("cache-control".": "."No-cache");
?>
